/**
 * GymPro Premium Elite — Shared Core
 */

const GymDB = {
  getUsers: () => JSON.parse(localStorage.getItem('gym_users')) || [
    { id:1, name:'امیررضا علوی', phone:'09121112233', gender:'male', status:'active', days:24, fee:850000, joinDate:'1403/01/10', birthdate:'1370/04/12', photo:null, note:'تمرینات قدرتی' },
    { id:2, name:'سارا کریمی', phone:'09354445566', gender:'female', status:'active', days:3, fee:700000, joinDate:'1403/02/05', birthdate:'1375/04/15', photo:null, note:'یوگا' },
    { id:3, name:'محمد جوادی', phone:'09197778899', gender:'male', status:'expired', days:0, fee:900000, joinDate:'1402/08/20', birthdate:'1368/06/01', photo:null, note:'' },
    { id:4, name:'نیلوفر رضایی', phone:'09361234567', gender:'female', status:'active', days:15, fee:750000, joinDate:'1403/03/01', birthdate:'1380/04/14', photo:null, note:'کاردیو' }
  ],
  saveUsers: u => localStorage.setItem('gym_users', JSON.stringify(u)),
  getSettings: () => JSON.parse(localStorage.getItem('gym_settings')) || { clubName:'GymPro Elite', apiKey:'GYM-API-2026-X', smsBalance:1250, globalFee:850000 },
  saveSettings: s => localStorage.setItem('gym_settings', JSON.stringify(s)),
  logout: () => { UI.showLoading(); setTimeout(() => location.href='index.html', 400); }
};

/* ===== Toast System ===== */
const UI = {
  _root: null,
  _getRoot() {
    if (!this._root) {
      this._root = document.createElement('div');
      this._root.className = 'toast-root';
      document.body.appendChild(this._root);
    }
    return this._root;
  },

  showToast(msg, type = 'success') {
    const root = this._getRoot();
    const icon = type === 'success' ? 'check' : 'alert-triangle';
    const t = document.createElement('div');
    t.className = `toast-item ${type}`;
    t.innerHTML = `<div class="t-icon"><i data-lucide="${icon}"></i></div><span>${msg}</span>`;
    root.appendChild(t);
    if (window.lucide) lucide.createIcons();
    setTimeout(() => {
      t.classList.add('toast-out');
      setTimeout(() => t.remove(), 280);
    }, 3000);
  },

  showLoading() {
    let el = document.getElementById('g-loader');
    if (!el) {
      el = document.createElement('div');
      el.id = 'g-loader';
      el.style.cssText = 'position:fixed;inset:0;background:rgba(255,255,255,0.8);backdrop-filter:blur(4px);z-index:9999;display:flex;align-items:center;justify-content:center;';
      el.innerHTML = '<div style="width:26px;height:26px;border:3px solid #f4f9eb;border-top-color:#87A922;border-radius:50%;animation:spin 0.7s linear infinite;"></div>';
      document.body.appendChild(el);
    }
    el.style.display = 'flex';
  },

  disableBtn(btn, text = 'در حال انجام...') {
    btn.disabled = true;
    btn.dataset.orig = btn.innerHTML;
    btn.innerHTML = `<span style="width:12px;height:12px;border:2px solid rgba(255,255,255,0.4);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;display:inline-block;margin-left:5px;"></span>${text}`;
  },

  enableBtn(btn) {
    btn.disabled = false;
    btn.innerHTML = btn.dataset.orig;
    if (window.lucide) lucide.createIcons();
  },

  validateForm(formId) {
    const inputs = document.getElementById(formId).querySelectorAll('[required]');
    let ok = true;
    inputs.forEach(inp => {
      if (!inp.value.trim()) {
        inp.classList.add('shake');
        inp.style.borderColor = 'var(--danger)';
        setTimeout(() => inp.classList.remove('shake'), 350);
        ok = false;
      } else inp.style.borderColor = 'var(--border)';
    });
    if (!ok) this.showToast('فیلدهای اجباری را کامل کنید', 'error');
    return ok;
  }
};

/* ===== Quick Renew Modal ===== */
const QuickRenew = {
  open(userId) {
    let ov = document.getElementById('qr-ov');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'qr-ov';
      ov.className = 'modal-ov';
      ov.innerHTML = `
        <div class="modal-box">
          <div style="width:46px;height:46px;background:var(--p-light);border-radius:13px;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;color:var(--p);">
            <i data-lucide="refresh-cw" style="width:21px;height:21px;"></i>
          </div>
          <h3 style="font-weight:900;font-size:0.95rem;margin-bottom:3px;" id="qr-name">تمدید سریع</h3>
          <p style="font-size:0.75rem;color:var(--muted);margin-bottom:14px;">اشتراک فعلی: <strong id="qr-cur" style="color:var(--p);">—</strong></p>
          <div class="renew-presets" style="margin-bottom:14px;">
            <button class="r-preset on" data-d="30">۱ ماه<small>۳۰ روز</small></button>
            <button class="r-preset" data-d="90">۳ ماه<small>۹۰ روز</small></button>
            <button class="r-preset" data-d="180">۶ ماه<small>۱۸۰ روز</small></button>
            <button class="r-preset" data-d="365">۱ سال<small>۳۶۵ روز</small></button>
          </div>
          <input type="number" id="qr-days" value="30" class="form-input ltr" style="text-align:center;font-size:1.2rem;font-weight:900;margin-bottom:14px;">
          <div style="display:flex;gap:8px;">
            <button class="btn btn-primary" id="qr-ok" style="flex:1;padding:11px;">تایید تمدید</button>
            <button onclick="QuickRenew.close()" class="btn btn-ghost" style="flex:1;padding:11px;">انصراف</button>
          </div>
        </div>`;
      document.body.appendChild(ov);
      ov.addEventListener('click', e => { if (e.target===ov) this.close(); });
      ov.querySelectorAll('.r-preset').forEach(b => {
        b.onclick = () => {
          ov.querySelectorAll('.r-preset').forEach(x => x.classList.remove('on'));
          b.classList.add('on');
          document.getElementById('qr-days').value = b.dataset.d;
        };
      });
    }
    const users = GymDB.getUsers();
    const u = users.find(x => x.id === userId);
    if (!u) return;
    document.getElementById('qr-name').innerText = u.name;
    document.getElementById('qr-cur').innerText = u.days + ' روز';
    document.getElementById('qr-days').value = 30;
    ov.querySelectorAll('.r-preset').forEach(b => b.classList.remove('on'));
    ov.querySelector('[data-d="30"]').classList.add('on');
    document.getElementById('qr-ok').onclick = () => {
      const d = parseInt(document.getElementById('qr-days').value) || 30;
      u.days = parseInt(u.days) + d;
      u.status = 'active';
      GymDB.saveUsers(users);
      this.close();
      UI.showToast(`اشتراک ${u.name} — ${d} روز تمدید شد`);
      if (typeof render === 'function') setTimeout(render, 40);
    };
    if (window.lucide) lucide.createIcons();
    requestAnimationFrame(() => ov.classList.add('open'));
  },
  close() {
    const ov = document.getElementById('qr-ov');
    if (ov) ov.classList.remove('open');
  }
};

/* ===== Floating Action Menu ===== */
const FM = {
  _el: null,
  show(anchor, items) {
    this.hide();
    const el = document.createElement('div');
    el.id = 'float-menu';
    items.forEach(item => {
      const b = document.createElement(item.href ? 'a' : 'button');
      b.className = 'fm-item';
      if (item.href) b.href = item.href;
      b.innerHTML = `<i data-lucide="${item.icon}" style="width:14px;height:14px;"></i>${item.label}`;
      if (item.fn) b.onclick = () => { this.hide(); item.fn(); };
      el.appendChild(b);
    });
    document.body.appendChild(el);
    this._el = el;
    const r = anchor.getBoundingClientRect();
    const w = 160;
    let left = r.right - w;
    if (left < 6) left = 6;
    let top = r.bottom + 5;
    if (top + 100 > window.innerHeight) top = r.top - 105;
    el.style.cssText += `;left:${left}px;top:${top}px;width:${w}px;`;
    requestAnimationFrame(() => el.classList.add('open'));
    if (window.lucide) lucide.createIcons();
  },
  hide() { if (this._el) { this._el.remove(); this._el = null; } }
};
document.addEventListener('click', e => {
  if (FM._el && !FM._el.contains(e.target) && !e.target.closest('.action-mob-btn')) FM.hide();
});

/* ===== Helpers ===== */
const persianToday = () => new Intl.DateTimeFormat('fa-IR').format(new Date());
const norm = s => (s||'').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d).toString());

const isBdSoon = (bd, days=7) => {
  if (!bd) return false;
  const parts = norm(bd).split('/');
  if (parts.length < 3) return false;
  const bMD = parts[1].padStart(2,'0') + '/' + parts[2].padStart(2,'0');
  const today = new Date();
  for (let i=0; i<=days; i++) {
    const d = new Date(today); d.setDate(today.getDate()+i);
    const s = norm(new Intl.DateTimeFormat('fa-IR').format(d)).split('/');
    if (s.length >= 3 && s[1].padStart(2,'0')+'/'+s[2].padStart(2,'0') === bMD) return true;
  }
  return false;
};

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) lucide.createIcons();
  document.querySelectorAll('input[type="tel"]').forEach(inp => {
    inp.addEventListener('input', e => e.target.value = e.target.value.replace(/[^0-9]/g,''));
  });
});
